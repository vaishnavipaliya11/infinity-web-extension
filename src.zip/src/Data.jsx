const QuoteData = [
  {
    quote: " The purpose of our lives is to be happy. "
    
  },
  {
    quote: "life is unpredictable face it anyway"
   
  },
  {
    quote: "Turn your wounds into wisdom."
  },
  {
    quote: "Work for your dream"
    
  },
  {
    quote:"honesty never goes out of style"
  },
  {
    quote:
      "be trustworthy"
  },
  {
    quote:
"Be attentive, Be strong"  },
  {
    quote:
      "be trustworthy"
  },
];

export { QuoteData };
